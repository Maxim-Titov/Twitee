<?php
$host = 'db';
$dbname = 'user_database';
$username = 'maxim';
$password = 'admin';
?>
